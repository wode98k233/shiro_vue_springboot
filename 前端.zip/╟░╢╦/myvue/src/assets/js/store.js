import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);


export default new Vuex.Store({
  state:{
    user: {
      id:null,
      username: null,
      password: null,
    },
    baseURL:"http://localhost:8086",//后端端口
    windowURL:"http://localhost:8085/",//本地端口
    // 存储token
    Authorization: sessionStorage.getItem('Authorization') ? sessionStorage.getItem('Authorization') : '',
    //选择的main的子页面
    SelectedActive: 2
  },
  getters:{},
  mutations:{

  },
  actions:{},
})
