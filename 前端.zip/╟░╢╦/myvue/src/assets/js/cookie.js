export function setCookie(key,value) {
  let exdate = new Date();//获取时间
  exdate.setTime(exdate.getTime() +  15*60*1000); //保存的时间,15分钟
  //字符串拼接cookie
  window.document.cookie = key + "=" + value + ";path=/;expires=" + exdate.toGMTString();
}

//读取cookie
export function getCookie(cname) {
  var name = cname + "=";
  var ca = document.cookie.split(';');
  for(var i=0; i<ca.length; i++) {
    var c = ca[i].trim();
    if (c.indexOf(name)==0) { return c.substring(name.length,c.length); }
  }
  return "";

}
//删除指定cookie的值
export function removeCookie(cname){
  var name = cname + "=";
  var ca = document.cookie.split(';');
  var cookieStr="";
  for(var i=0; i<ca.length; i++) {
    var c = ca[i].trim();
    if (c.indexOf(name)==0) {
      document.cookie =c + ';expires=' + new Date(0).toUTCString()
    }else{
      cookieStr+=c;
      cookieStr+=";";
    }
    document.cookie =cookieStr;

  }

}
//删除全部的cookie值
export function clearCookie(){
  var keys=document.cookie.match(/[^ =;]+(?=\=)/g);
  if (keys) {
    for (var i = keys.length; i--;) ;
    document.cookie=keys[i]+'=0;expires=' + new Date( 0).toUTCString() ;
  }
}
