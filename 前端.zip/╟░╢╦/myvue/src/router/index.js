import Vue from 'vue'
import Router from 'vue-router'
import login from '../components/login'
import Main from '../components/main'
import store from "../assets/js/store";
import NotFound from "../components/404"
import axios from "axios";
import FileDownload from "../components/view/FileDownload";
import Fileupload from "../components/view/Fileupload";
import userprofile from "../components/view/userprofile";
import signup from "../components/signup";
import {
  Message,
  MessageBox
} from 'element-ui'
Vue.use(Router)
const router= new Router({
  mode:"history",
  routes: [
    {
      path: '/',
      name: 'login',
      props:true,
      component: login
    },
    {
      //路由路径
      path: '/main',
      name: 'Main',
      //跳转的组件
      component: Main,
      //嵌套路由
      children: [
        //:id
        {path:'/main/userprofile',name:'userprofile' ,component:userprofile,props:true},//个人中心
        {path:'/main/Fileupload',name:'Fileupload' ,component:Fileupload,props:true},//文件上传
        {path:'/main/',name:'FileDownload' ,component:FileDownload,props:true},//文件下载
      ]
    },
    {
      //路由路径
      path: '*',
      //跳转的组件
      component: NotFound
    },
    {
      path: '/signup',
      name: 'signup',
      props:true,
      component: signup
    },
  ]
})









export default router
router.beforeEach((to, from, next) => {

  /**
   * 先从store获取username和password，然后再访问后端登录接口，
   * 若返回ok，则登录成功可以继续跳转到该跳转的路由
   * */
  if (sessionStorage.getItem('store')) {
    store.replaceState(Object.assign({}, store.state, JSON.parse(sessionStorage.getItem('store'))));
  }

  //在页面刷新时将vuex里的信息保存到sessionStorage里
  window.addEventListener('beforeunload', () => {
    sessionStorage.setItem('store', JSON.stringify(store.state));
  });

  if (to.path === '/'||to.path==='/signup') {
    //console.log("现在去登录页")
    next();
  } else {
    /**
     * 获取session内数据
     * */
    let token = sessionStorage.getItem('Authorization');
    if (token === null || token === '') {
      next('/');
    } else {
      //console.log("跳转ing")
      next();
    }
  }
  window.setInterval(() => {
    setTimeout(function(){
      const _this = this;
      axios.get(  'http://localhost:8086/user/findAll').then(res => {
        if (res.data==='no'){
          Message({
            message: '登录信息已经过期，请重新登录',
            type: 'warning',
            duration: 60 * 1000
          })
        }
      }).catch(error => {
       console.log(error)
      });
      }, 0)
  }, 60000)//五分钟看一下是否是未登录
})


