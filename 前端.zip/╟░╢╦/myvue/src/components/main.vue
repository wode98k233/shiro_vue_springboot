<template>
<div >

  <el-container style=" border: 1px solid #eee">
    <el-aside width="auto" style="background-color: rgb(238, 241, 246)">
      <el-menu
        :default-active="this.$store.state.SelectedActive+''"
        class="el-menu-vertical-demo"
        @open="handleOpen"
        @close="handleClose"
        background-color="#545c64"
        text-color="#fff"
        active-text-color="#ffd04b">
        <el-menu-item index="1" @click="Routo(2)">
          <i class="el-icon-menu"  ></i>
          <span slot="title">文件上传</span>
        </el-menu-item>
        <el-menu-item index="2" @click="Routo(1)">
          <i class="el-icon-files" ></i>
          <span slot="title" >文件下载</span>
        </el-menu-item>
        <el-menu-item index="3" @click="Routo(3)">
          <i class="el-icon-setting" ></i>
          <span slot="title" >个人中心</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-main width="auto" >
      <router-view></router-view>
    </el-main>
  </el-container>
  <el-button type="primary" round v-on:click="Return()">返回首页</el-button>
  <el-button type="primary" round v-on:click="Logout()">注销</el-button>

</div>
</template>

<script>
import store from "../assets/js/store";

export default {
  name: "Main",
  data() {
    return {
      }
  },
  methods: {
    Routo(val){
      switch(val){
        case 1://文件下载
          this.$store.state.SelectedActive=2;
          sessionStorage.setItem('store', JSON.stringify(store.state));
          if(window.location.href!==this.$store.state.windowURL+"main") {
            this.$router.push({name: 'FileDownload'});
          }else{
            location. reload();
          }
          break;
        case 2://文件上传
          this.$store.state.SelectedActive=1;
          sessionStorage.setItem('store', JSON.stringify(store.state));
          if(window.location.href!==this.$store.state.windowURL+"main/Fileupload") {
            this.$router.push({name: 'Fileupload'});
          }else{
            location. reload();
          }
          break;
        case 3://个人信息
          this.$store.state.SelectedActive=3;
          sessionStorage.setItem('store', JSON.stringify(store.state));
          if(window.location.href!==this.$store.state.windowURL+"main/userprofile"){
            this.$router.push({name: 'userprofile'});}else {
            location. reload();
          }
          break;
      }
    },
    handleOpen(key, keyPath) {
    },
    handleClose(key, keyPath) {
    },

    Return() {
      console.log(this.$store.state.user)
      this.$router.push({path: '/'});
    },
    Logout() {
      this.$store.state.user.username="";
      this.$store.state.user.password="";
      sessionStorage.removeItem("store")
      sessionStorage.removeItem("Authorization");
      this.$axios.get(this.$store.state.baseURL+'/static/logout').then(function (resp){
        console.log(resp)
      }).catch(function (error){
        _this.$notify.error({title: '错误', message: error});})
      this.$router.push({path: '/'});
    },
    LoadFile(){
      const _this = this;
      this.axios.get(_this.$store.state.baseURL + '/file/findAll').then(res => {
        this.tableData=res.data;
      }).catch(error => {
        _this.$notify.error({
          title: '失败',
          message: '服务器正在忙碌中'
        });
      });
    }
    ,LoadUser() {
      const _this = this;
      this.axios.get(_this.$store.state.baseURL + '/user/selectByName?' + 'name=' + _this.$store.state.user.username).then(res => {
        this.$store.state.user.id=res.data.id;
      }).catch(error => {
        _this.$notify.error({
          title: '失败',
          message: '服务器正在忙碌中'
        });
      });
    },
  loadDload(){
    const _this = this;
    this.axios.get(_this.$store.state.baseURL + '/dloadfile/findAll').then(res => {
      this.gridData = res.data;
    }).catch(error => {
      _this.$notify.error({
        title: '失败',
        message: '服务器正在忙碌中'
      });
    });
  },
    Load(){
      this.LoadUser();
      //this.loadDload();
      //this.LoadFile();
    }
  },created() {
      this.Load();

  },
  beforeUpdate(){
    //this.Load();
  }
}
</script>

<style scoped>

</style>
