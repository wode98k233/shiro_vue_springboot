<template>
<div>
  <h1>注册界面</h1>
  <div>
    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
      <el-form-item label="账号名称" prop="name">
        <el-input maxlength="30" clearable show-word-limit v-model="ruleForm.name"></el-input>
      </el-form-item>
      <el-form-item label="账号密码" prop="password1">
        <el-input type="password" maxlength="30" show-password clearable show-word-limit v-model="ruleForm.password1"></el-input>
      </el-form-item>
      <el-form-item label="确认密码" prop="password2">
        <el-input type="password" maxlength="30" show-password clearable show-word-limit v-model="ruleForm.password2"></el-input>
      </el-form-item>
      <el-form-item label="性别" prop="sex">
        <el-select v-model="ruleForm.sex" placeholder="请选择性别">
          <el-option label="男" value="男"></el-option>
          <el-option label="女" value="女"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item label="邮箱" prop="email">
        <el-input  v-model="ruleForm.email" clearable show-word-limit maxlength="30"></el-input>
      </el-form-item>

      <el-form-item label="手机号" prop="phone">
        <el-input  v-model="ruleForm.phone" clearable show-word-limit maxlength="15"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm('ruleForm')">注册</el-button>
        <el-button @click="resetForm('ruleForm')">重置</el-button>
      </el-form-item>
    </el-form>
  </div>
</div>
</template>

<script>


export default {
  name: "signup",
  data(){
    return{

      ruleForm: {
        id:'',
        name: '',
        sex: '',
        password1: '',
        password2: '',
        buildTime:'',
        buildDate:'',
        email: '',
        phone:'',
      },
      rules: {
        sex: [
          { required: true, message: '请选择性别', trigger: 'blur' }
        ],
        email: [
          { required: true, message: '请填写邮箱', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: '请填写手机号', trigger: ['blur','change'] }
        ],
        name: [
          { required: true, message: '请填写名称', trigger: ['blur','change']}
        ],
        password1: [
          { required: true,  trigger: 'blur' ,validator:this.SurePassword }
        ],password2: [
          { required: true,  trigger: 'blur',validator:this.ReSurePassword }
        ]
    }}},
  methods: {
    SurePassword(rule,value,callback){
      if(!value){
        callback(new Error("请输入密码"))
      }else{
        callback();
      }
    },ReSurePassword(rule,value,callback){
      if(!value){
        callback(new Error("请确认密码"))
      }else if(!(value===this.ruleForm.password1)){
        callback(new Error("两次输入的密码不一致"))
      }else{
        callback();
      }
    },
    submitForm(formName) {
      const self = this;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$axios.post(this.$store.state.baseURL+'/user/insert', {id:0,
            name:self.ruleForm.name,
          password:self.ruleForm.password1,
          sex:self.ruleForm.sex,
          email:self.ruleForm.email,
          phone:self.ruleForm.phone,
          btime:0}).then((res)=>{
            console.log(res)
          });
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
    },
}
</script>

<style scoped>

</style>
