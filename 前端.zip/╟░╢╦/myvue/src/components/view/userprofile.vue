<template>
  <div>
    <h1>个人中心</h1>
    <div>
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="ID">
          <el-input v-model="ruleForm.id" :disabled="true"></el-input>
        </el-form-item>
        <el-form-item label="账号名称" prop="name">
          <el-input maxlength="30" clearable show-word-limit v-model="ruleForm.name" :disabled="disabled"></el-input>
        </el-form-item>
        <el-form-item label="账号密码" prop="password1">
          <el-input type="password" maxlength="30" show-password clearable show-word-limit v-model="ruleForm.password1"
                    :disabled="disabled"></el-input>
        </el-form-item>
        <el-form-item label="确认密码" prop="password2">
          <el-input type="password" maxlength="30" show-password clearable show-word-limit v-model="ruleForm.password2"
                    :disabled="disabled"></el-input>
        </el-form-item>
        <el-form-item label="性别" prop="sex">
          <el-select v-model="ruleForm.sex" placeholder="请选择性别" :disabled="disabled">
            <el-option label="男" value="男"></el-option>
            <el-option label="女" value="女"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="创建时间" required>
          <el-col :span="11">
            <el-form-item>
              <el-date-picker type="date" placeholder="选择日期" v-model="ruleForm.buildDate" style="width: 100%;"
                              :disabled="true"></el-date-picker>
            </el-form-item>
          </el-col>
          <el-col class="line" :span="2">-</el-col>
          <el-col :span="11">
            <el-form-item >
              <el-input  placeholder="选择时间" v-model="ruleForm.buildTime" style="width: 100%;"
                              :disabled="true"></el-input>
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item label="邮箱" prop="email">
          <el-input v-model="ruleForm.email" clearable show-word-limit :disabled="disabled"></el-input>
        </el-form-item>

        <el-form-item label="手机号" prop="phone">
          <el-input v-model="ruleForm.phone" clearable show-word-limit :disabled="disabled"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="resetForm()">修改</el-button>
          <el-button @click="submitForm('ruleForm')">确认修改</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import store from "../../assets/js/store";

export default {
  name: "userprofile",
  data() {
    return {
      //禁用状态
      disabled: true,
      ruleForm: {
        id: '',
        name: '',
        sex: '',
        password1: '',
        password2: '',
        buildTime: '',
        buildDate: '',
        bitme:null,
        email: '',
        phone: '',
      },
      rules: {
        sex: [
          {required: true, message: '请选择性别', trigger: 'blur'}
        ],
        email: [
          {required: true, message: '请填写邮箱', trigger: 'blur'}
        ],
        phone: [
          {required: true, message: '请填写手机号', trigger: ['blur', 'change']}
        ],
        name: [
          {required: true, message: '请填写名称', trigger: ['blur', 'change']}
        ],
        password1: [
          {required: true, trigger: 'blur', validator: this.SurePassword}
        ], password2: [
          {required: true, trigger: 'blur', validator: this.ReSurePassword}
        ]
      }
    }
  },
  methods: {
    //密码规则
    SurePassword(rule, value, callback) {
      if (!value) {
        callback(new Error("请输入密码"))
      } else {
        callback();
      }
    }, ReSurePassword(rule, value, callback) {
      if (!value) {
        callback(new Error("请确认密码"))
      } else if (!(value === this.ruleForm.password1)) {
        callback(new Error("两次输入的密码不一致"))
      } else {
        callback();
      }
    },
    //提交修改
    submitForm(formName) {
      const self = this;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.axios.put(self.$store.state.baseURL + '/user/update' ,
            {
              id:self.ruleForm.id,
              name:self.ruleForm.name,
              password:self.ruleForm.password1,
              sex:self.ruleForm.sex,
              email:self.ruleForm.email,
              phone:self.ruleForm.phone,
              btime:self.ruleForm.btime
            }).then(res => {
            self.$notify.success({
              title: '成功',
              message: '成功修改'
            });
          }).catch(error => {
            self.$notify.error({
              title: '失败',
              message: '修改信息失败，请稍后再试'
            });
          });

        } else {
          self.$notify.warning({
            title: '警告',
            message: '请按照规则填写信息'
          });
          return false;
        }
      });
      this.disabled = true;
    },
    resetForm() {
      this.disabled = false;
    },
    LoadUser() {
      const _this = this;
      this.axios.get(_this.$store.state.baseURL + '/user/selectByName?' + 'name=' + _this.$store.state.user.username).then(res => {
        _this.ruleForm.id=res.data.id;
        _this.ruleForm.name=res.data.name;
        _this.ruleForm.sex=res.data.sex;
        _this.ruleForm.password1=res.data.password;
        _this.ruleForm.password2=res.data.password;
        _this.ruleForm.phone=res.data.phone;
        _this.ruleForm.email=res.data.email;
        _this.ruleForm.btime=res.data.btime;
        _this.ruleForm.buildDate=res.data.btime.split(' ')[0];
        _this.ruleForm.buildTime=res.data.btime.split(' ')[1];
      }).catch(error => {
        _this.$notify.error({
          title: '失败',
          message: '服务器正在忙碌中'
        });
      });
    },
    LoadInformation() {
      this.LoadUser();
    }
  },
  created() {
    this.LoadInformation()
  },
  mounted() {

  },
  beforeUpdate(){
    this.LoadInformation()
  }

}
</script>

<style scoped>

</style>
