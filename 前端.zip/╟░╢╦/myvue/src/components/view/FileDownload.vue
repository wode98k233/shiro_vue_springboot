<template>
  <div>
    <!-- Table -->
    <el-button type="text" @click="dialogTableVisible = true"><h1>文件下载</h1></el-button>
    <el-dialog title="收货地址" :visible.sync="dialogTableVisible">
      <el-table :data="gridData">
        <el-table-column property="time" label="下载日期" width="150"></el-table-column>
        <el-table-column property="uname" label="下载者" width="200"></el-table-column>
        <el-table-column property="fname" label="文件名"></el-table-column>
      </el-table>
    </el-dialog>
    <!--表格，文件列表，可以展开查看文件详细信息和下载文件,管理员可以删除文件-->
    <div>
      <template>
        <el-table
          :data="tableData.filter(data => !search || data.type.toLowerCase().includes(search.toLowerCase()))"
          style="width: 100%">
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-form label-position="left" inline class="demo-table-expand">
                <el-form-item label="文件流号">
                  <span>{{ props.row.path }}</span>
                </el-form-item>
                <el-form-item label="上传时间">
                  <span>{{ props.row.time }}</span>
                </el-form-item>
                <el-form-item label="上传者">
                  <span>{{ props.row.uper }}</span>
                </el-form-item>
                <el-form-item label="文件大小">
                  <span>{{ props.row.size }}</span>
                </el-form-item>
                <el-form-item label="文件格式">
                  <span>{{ props.row.type }}</span>
                </el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column
            label="编号"
            prop="id">
          </el-table-column>
          <el-table-column
            label="文件名"
            prop="name">
          </el-table-column>
          <el-table-column
            align="right">
            <template slot="header" slot-scope="scope">
              <el-input
                v-model="search"
                size="mini"
                placeholder="输入文件名的关键字搜索"/>
            </template>
            <template slot-scope="scope">
              <el-button
                size="mini"
                icon="el-icon-download"
                type="primary"
                @click="handleEdit(scope.$index, scope.row)"></el-button>
              <el-button
                size="mini"
                type="danger"
                icon="el-icon-delete"
                @click="handleDelete(scope.$index, scope.row)"></el-button>
            </template>
          </el-table-column>
        </el-table>
      </template>
    </div>

  </div>
</template>

<script>
export default {
  name: "FileDownload",
  data() {
    return {
      /**
       * Author：Liu
       * 数据模型，从store。state中获取
       * */
      tableData: [{
        time: '2021-04-02 11:23:16',
        id: 88888888,
        name: "未连接",
        uper: '无人响应',
        path: 'no.no',
        size: '1024MB',
        type: 'no',
      }],
      //查询内容
      search: null,
      //对话框，下载历史记录
      gridData: [{
        time: null,
        uname: null,
        fname: null,
        hid:null,
        fid:null,
        uid:null,
      }],
      dialogTableVisible: false,
    }
  },
  methods: {
    //查询文件格式
    filter(){

    },
    //下载文件
    DownloadFile(filename,suffix){
      window.location.href=this.$store.state.baseURL+'/fileuntil/download?fileName='+filename+'&suffix='+suffix.split('.')[1];
      /*this.$axios.get(this.$store.state.baseURL+'/fileuntil/download?fileName='+filename+'&suffix='+suffix.split('.')[1]).then(res=>{
        console.log(res)
      }).catch(err=>{
        console.log(err)
      })*/
    },
    handleEdit(index, row) {
      /**
       * 1先插入下载记录，
       * 2再访问后端文件下载端口
       * */
      const self = this;
      this.$axios.post(this.$store.state.baseURL+'/dloadfile/insert', {
        hid:null,
        uid:self.$store.state.user.id,
        fid:row.id,
        time:null,
        fname:row.name,
        uname:self.$store.state.user.username,
      }).then(resp =>{
        this.loadDload()
        this.DownloadFile(row.path,row.path)

      }).catch(error => {
        self.$notify.error({
          title: '失败',
          message: '服务器正在忙碌中'
        });
      });

      //console.log(index, row);
    },
    //删除文件
    DeleteFile(path,suffix){
      const self = this;
      this.$axios.delete(self.$store.state.baseURL+"/fileuntil/deleteFile", {params:{path: path,suffix:suffix}}).then(response=>{
        self.$notify.success({
          title: '成功',
          message: '成功删除文件'+path.split('.')[0]
        });
        self.Load()
      }) .catch(err=>{
        self.$notify.error({
          title: '失败',
          message: '服务器正忙'
        });
      });

    },
    handleDelete(index, row) {
      if(this.$store.state.user.id==1){
        const self = this;
        console.log(row)
        this.$axios.delete(self.$store.state.baseURL+"/file/delete", {params:{id: row.id}}).then(response=>{
          self.DeleteFile(row.path,row.path.split('.')[1])
        }) .catch(err=>{
          self.$notify.error({
            title: '失败',
            message: '服务器正忙'
          });
        });
      }else{
        this.$notify.warning({
          title: '警告',
          message: '只有管理员才能删除文件'
        });
      }

    },
    LoadFile() {
      const _this = this;
      this.axios.get(_this.$store.state.baseURL + '/file/findAll').then(res => {
        this.tableData = res.data;
      }).catch(error => {
        _this.$notify.error({
          title: '失败',
          message: '服务器正在忙碌中'
        });
      });
    },
    loadDload(){
      const _this = this;
      this.axios.get(_this.$store.state.baseURL + '/dloadfile/findAll').then(res => {
        this.gridData = res.data;
      }).catch(error => {
        _this.$notify.error({
          title: '失败',
          message: '服务器正在忙碌中'
        });
      });
    },
    Load() {
      this.LoadFile();
      this.loadDload();
    }
  },
  created() {
    this.Load();
  },
  beforeUpdate() {

  }

}
</script>

<style scoped>
.demo-table-expand {
  font-size: 0;
}

.demo-table-expand label {
  width: 90px;
  color: #99a9bf;
}

.demo-table-expand .el-form-item {
  margin-right: 0;
  margin-bottom: 0;
  width: 50%;
}
</style>
