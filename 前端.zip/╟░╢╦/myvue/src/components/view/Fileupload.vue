<template>
  <div>
    <h1>文件上传</h1>
    <div>
      <el-upload
        class="upload-demo"
        drag
        :headers = "headers"
        :action="this.$store.state.baseURL+'/fileuntil/uploadFile'"
        :multiple="false"
        :limit='1'
        :on-success="FileuploadSuccess"
        :on-error="FileuploadError"
      >
        <i class="el-icon-upload"></i>
        <div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
        <div class="el-upload__tip" slot="tip">每次只能上传一个文件，若多文件上传请先打包成zip格式，单次上传文件大小不得超过30MB</div>
      </el-upload>
       <div v-for="i in 10"><br></div>
    </div>
    <!--提示-->
    <div>
      <el-collapse accordion>
        <el-collapse-item title="帮助" name="1">
          <div>上传文件流程操作如下</div>
          <el-tree :data="Tree_data" :props="defaultProps" @node-click="handleNodeClick"></el-tree>
        </el-collapse-item>
        <el-collapse-item title="反馈" name="2">
          <div>
            意见上传请发送邮件给
            <el-button type="text" @click="dialogVisible = true">1009748481@qq.com</el-button>
            </div>
        </el-collapse-item>
        <el-collapse-item title="给个好评" name="3">
          <div>亲，给个五星好评吧＜（＾－＾）＞</div>
          <div>
            <el-rate
              show-text
              :colors="colors"
            >
            </el-rate>
          </div>
        </el-collapse-item>
        <el-collapse-item title="赞赏" name="4">
          <div><el-button type="text" @click="dialogVisible2 = true">获取赞赏二维码</el-button></div>
        </el-collapse-item>
      </el-collapse>
    </div>
    <!--对话框-->
    <div>
      <el-dialog
        title="提示"
        :visible.sync="dialogVisible"
        width="30%"
        :before-close="handleClose">
        <span>意见内容如下</span>
        <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible = false">确 定</el-button>
  </span>
      </el-dialog>
      <el-dialog
        title="提示"
        :visible.sync="dialogVisible2"
        width="30%"
        :before-close="handleClose">
        <span>赞赏二维码</span>
        <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible2 = false">取 消</el-button>
    <el-button type="primary" @click="dialogVisible2 = false">确 定</el-button>
  </span>
      </el-dialog>
    </div>
  </div>
</template>

<script>
export default {
  name: "Fileupload",
  data() {
    return {

      Tree_data: [{label: '第一步', children: [{label: '点击或者拖拽文件到上传区域'}]}, {label: '第二布', children: [{label: '选择要上传的文件',}]}, {label: '第三步', children: [{label: '点击确认按钮',}]}, {label: '上传失败原因', children: [{label: '1、选择了多个文件但没有打包成压缩包格式',}, {label: '2、上传的文件>=30MB'}, {label: '3、请确认网络正常'}]}], defaultProps: {children: 'children', label: 'label'},
      dialogVisible: false,
      dialogVisible2: false,
      colors: {1:'#99A9BF',2:'#bcbf99',3:'#e8c547' , 4:'#F7BA2A',5:'#FF9900'} ,
      headers: {
        AUTH_TOKEN : sessionStorage.getItem('Authorization')
      }

    }
  },
  methods: {
    //上传帮助里面树形控件点击效果
    handleNodeClick(data) {},
    //对话框
    handleClose(done) {
      this.$confirm('确认关闭？')
        .then(_ => {
          done();
        })
        .catch(_ => {});
    },
    //文件上传成功,弹出成功的消息，并且给数据库添加消息
    FileuploadSuccess(response,file){
      console.log(file.name.split('.')[0])
      console.log(response.split(':')[1])
      this.$notify.success({
        title: '成功',
        message: '文件上传成功'
      });
      const self = this;
      this.$axios.post(this.$store.state.baseURL+'/file/insert', {id:0,
        name:file.name.split('.')[0],
        path:response.split(':')[1],
        time:0,
        uper:self.$store.state.user.username,
        size:file.size/(1024*1024)+'MB',
        type:file.name.split('.')[1]
      }).catch(error => {
        _this.$notify.error({
          title: '失败',
          message: '服务器正在忙碌中'
        });
      });
    },
    //文件上传失败
    FileuploadError(){
      this.$notify.error({
        title: '失败',
        message: '文件上传失败'
      });
    }
  }
}
</script>

<style scoped>

</style>
