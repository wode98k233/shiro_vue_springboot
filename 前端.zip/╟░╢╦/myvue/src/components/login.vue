<template>
  <!--登录-->
  <div>
    <img src="../assets/logo.png">
    <br>
    <h1>Please sign in</h1>
    <el-input style="width:250px" clearable maxlength="30" show-word-limit placeholder='Username' type="text"
              v-model="username">
    </el-input>
    <br><br>
    <el-input style="width:250px" show-password clearable maxlength="30" show-word-limit placeholder='Password'
              type="password" v-model="password">
    </el-input>
    <br><br>
    <br>
    <el-button type="primary" round v-on:click="Login(username,password)">Sign in</el-button>
    <el-button type="danger" round v-on:click="Sign_Up()">Sign up</el-button>
    <p class="mt-5 mb-3 text-muted">© 2020-2021</p>
  </div>
</template>

<script>
import axios from "axios";
import store from "../assets/js/store";

export default {
  name: "login",
  data() {
    return {
      password: "",
      username: "",
      userToken: "",
    }
  },
  methods: {
    //注册界面
    Sign_Up(){
      this.$router.push({path: "/signup"});
    }
    ,
    login(username,password) {
      let _this = this;
      if (username === "" || password === "") {
        alert('账号或密码不能为空');
      } else {
        this.axios.get(_this.$store.state.baseURL + '/static/ulogin?' + 'username=' + _this.username + '&password=' + _this.password).then(res => {
          //console.log(res.data);
          if (res.data.data !== "error") {
            _this.userToken = res.data.errcode;
            //console.log(_this.userToken)
            // 将用户token保存到vuex中和保存到cookie中
            _this.$store.state.Authorization = _this.userToken;
            sessionStorage.setItem('Authorization', _this.$store.state.Authorization);
            sessionStorage.setItem('store',JSON.stringify(store.state));
            alert('登陆成功');
            let son=_this.$store.state.SelectedActive;
            let sonPath='';
            switch(son){
              case 1:sonPath="Fileupload";break;
              case 3:sonPath="userprofile";break;
              default:break;
            }
            this.$router.push({path: "/main/"+sonPath});
          } else {
            alert(res.data.errmsg);
          }
        }).catch(error => {
          alert('账号或密码错误');
          console.log(error);
        });
      }
    },
    Login(username, password) {
      this.$store.state.user.username = username;
      this.$store.state.user.password = password;
      this.login(username,password);

    }
  },
  created() {
    if (this.$store.state.user.username !== "" && this.$store.state.user.password !== "") {
      this.username = this.$store.state.user.username;
      this.password = this.$store.state.user.password;
    }
  }
}
</script>

<style scoped>

</style>
