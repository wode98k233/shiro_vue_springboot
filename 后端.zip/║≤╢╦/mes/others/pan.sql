-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: pan
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dloadfile`
--

DROP TABLE IF EXISTS `dloadfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dloadfile` (
  `hid` int NOT NULL,
  `uid` int NOT NULL,
  `fid` int NOT NULL,
  `time` timestamp(6) NOT NULL,
  `uname` varchar(45) COLLATE utf8_bin NOT NULL,
  `fname` varchar(45) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='文件下载记录 hid,用户的id，文件的id，下载时间,用户名，文件名';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dloadfile`
--

LOCK TABLES `dloadfile` WRITE;
/*!40000 ALTER TABLE `dloadfile` DISABLE KEYS */;
INSERT INTO `dloadfile` VALUES (318814988,1,6502090,'2021-04-12 03:21:20.551000','admin','日志');
/*!40000 ALTER TABLE `dloadfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file` (
  `id` int NOT NULL,
  `name` varchar(255) COLLATE utf8_bin NOT NULL,
  `path` varchar(255) COLLATE utf8_bin NOT NULL,
  `time` timestamp(6) NOT NULL,
  `uper` varchar(255) COLLATE utf8_bin NOT NULL,
  `size` varchar(255) COLLATE utf8_bin NOT NULL,
  `type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='文件表， id，名字（上传时候的名字），路径（名字（UUID生成的不重复的唯一名）+后缀） 创建时间，上传者,种类(zip,txt,jpg),\n大小(Kb-Mb)';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
INSERT INTO `file` VALUES (634433236,'43966e2f82b34e14b0eabac5e01712ff','870e48bd9699481d89eed94efd63ac28.png','2021-04-06 04:17:36.015000','星期一','2.2938709259033203MB','png'),(1277656101,'b','586ec61d760e405b82fabb76f519ca21.html','2021-04-06 07:03:34.962000','root','0.000213623046875MB','html'),(2057103913,'宝塔','34b41b0c1f09490588e52b03c316183d.txt','2021-04-07 15:26:14.144000','admin','0.0001316070556640625MB','txt'),(2084503363,'最新激活码','4149061cee04414a8bed4ea44a7bedf3.txt','2021-04-07 16:33:09.144000','root','0.004231452941894531MB','txt');
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL,
  `name` varchar(45) COLLATE utf8_bin NOT NULL,
  `password` varchar(45) COLLATE utf8_bin NOT NULL,
  `btime` timestamp(6) NOT NULL,
  `sex` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `email` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='用户类 id 用户名 密码 创建时间(2021-4-1 13:46:55) 性别 邮箱， 手机号';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','123456','2020-04-01 05:51:55.000000','男','123456789@Google.com','08633241'),(2,'root','123456','2021-04-02 03:23:16.000000','男','987654321@qq.com','7654537345'),(974383961,'星期二','money','2021-04-06 07:57:03.983000','女','Moneys@rich.com','88888888888'),(1037022770,'星期一','0pay','2021-04-06 07:58:50.671000','男','pool@pool.com','00000000000');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-12 12:03:26
