package com.panle.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class File {
    @Id
    private Integer id;

    private String name;
    private String path;
    private Timestamp time;
    private String uper;
    private String size;
    private String type;
}
