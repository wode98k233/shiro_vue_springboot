package com.panle.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Dloadfile {
    @Id
    private Integer hid;

    private Integer uid;
    private Integer fid;
    private Timestamp time;
    private String uname;
    private String fname;
}
