package com.panle.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

//@Configuration
//public class CrosConfig implements WebMvcConfigurer {
//    @Override
//    public void addCorsMappings(CorsRegistry registry) {
//        registry.addMapping("/**")
//                .allowedOrigins("*")
//                .allowedMethods("GET","HEAD","POST","PUT","DELETE","OPTIONS")
//                .allowCredentials(true)
//                .maxAge(3600)
//                .allowedHeaders("*");
//    }
//    @Override
//    public void addResourceHandlers(ResourceHandlerRegistry registry) {
//        registry.addResourceHandler("/mes/text/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/text/");
//        registry.addResourceHandler("/mes/html/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/html/");
//        registry.addResourceHandler("/mes/doc/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/doc/");
//        registry.addResourceHandler("/mes/pdf/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/pdf/");
//        registry.addResourceHandler("/mes/ppt/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/ppt/");
//        registry.addResourceHandler("/mes/zip/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/zip/");
//        registry.addResourceHandler("/mes/jpg/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/jpg/");
//        registry.addResourceHandler("/mes/others/**").addResourceLocations("file:D:/辩论/大三/下/项目/个人网盘开发/后端/mes/others/");
//    }
//
//}

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

@Configuration
public class CrosConfig {
    @Bean
    public CorsFilter corsFilter() {
        //1.添加CORS配置信息
        CorsConfiguration config = new CorsConfiguration();
        //放行哪些原始域
        config.addAllowedOrigin("*");
        //是否发送Cookie信息
        config.setAllowCredentials(true);
        //放行哪些原始域(请求方式)
        config.addAllowedMethod("*");
        //放行哪些原始域(头部信息)
        config.addAllowedHeader("*");
        //暴露哪些头部信息（因为跨域访问默认不能获取全部头部信息）
        config.addExposedHeader("content-type");

        //2.添加映射路径
        UrlBasedCorsConfigurationSource configSource = new UrlBasedCorsConfigurationSource();
        configSource.registerCorsConfiguration("/**", config);

        //3.返回新的CorsFilter.
        return new CorsFilter(configSource);
    }
}
