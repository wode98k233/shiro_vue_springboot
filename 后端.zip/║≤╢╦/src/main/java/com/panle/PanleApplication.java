package com.panle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PanleApplication {

    public static void main(String[] args) {
        SpringApplication.run(PanleApplication.class, args);
    }

}
