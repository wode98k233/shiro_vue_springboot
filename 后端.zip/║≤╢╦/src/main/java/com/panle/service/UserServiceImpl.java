package com.panle.service;

import com.panle.mapper.UserMapper;
import com.panle.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    UserMapper userMapper;

    @Override
    public User queryUserByName(String name) {
        return userMapper.queryUserByName(name);
    }
    @Override
    public List<User> findAll() {
        return userMapper.findAll();
    }
    @Override
    public int deleteByPrimaryKey(Integer id) {
        return userMapper.deleteByPrimaryKey(id);
    }
    @Override
    public int insert(User user) {
        return userMapper.insert(user);
    }
    @Override
    public User selectByPrimaryKey(Integer id) {
        return userMapper.selectByPrimaryKey(id);
    }
    @Override
    public int update(User user) {
        return userMapper.update(user);
    }

}
