package com.panle.service;

import com.panle.mapper.FileMapper;
import com.panle.mapper.UserMapper;
import com.panle.pojo.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class FileServiceImpl implements FileService{
    @Autowired
    FileMapper fileMapper;
    @Override
    public File queryFileByName(String name) {
        return fileMapper.queryFileByName(name);
    }

    @Override
    public List<File> findAll() {
        return fileMapper.findAll();
    }

    @Override
    public int deleteByPrimaryKey(Integer id) {
        return fileMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(File user) {
        return fileMapper.insert(user);
    }

    @Override
    public File selectByPrimaryKey(Integer id) {
        return fileMapper.selectByPrimaryKey(id);
    }

    @Override
    public int update(File user) {
        return fileMapper.update(user);
    }
}
