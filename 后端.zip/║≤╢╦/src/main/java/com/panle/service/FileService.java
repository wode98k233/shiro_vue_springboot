package com.panle.service;

import com.panle.pojo.File;

import java.util.List;

public interface FileService {
    public File queryFileByName(String name);
    public List<File> findAll();
    //按主键ID删除一条记录
    int deleteByPrimaryKey(Integer id);
    //新增一条记录，所有字段必须赋值，否则会报错
    int insert(File user);
    //根据主键ID查询
    File selectByPrimaryKey(Integer id);
    //根据实体类更新一条记录，部分更新只对有值的字段进行更新
    int update(File user);
}
