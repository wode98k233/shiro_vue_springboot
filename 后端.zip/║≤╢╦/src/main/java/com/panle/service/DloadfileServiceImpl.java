package com.panle.service;

import com.panle.mapper.DloadfileMapper;
import com.panle.mapper.UserMapper;
import com.panle.pojo.Dloadfile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class DloadfileServiceImpl implements DloadfileService{
    @Autowired
    DloadfileMapper dloadfileMapper;
    @Override
    public Dloadfile queryDloadfileByFName(String name) {
        return dloadfileMapper.queryDloadfileByFName(name);
    }

    @Override
    public Dloadfile queryDloadfileByUName(String name) {
        return dloadfileMapper.queryDloadfileByUName(name);
    }

    @Override
    public List<Dloadfile> findAll() {
        return dloadfileMapper.findAll();
    }

    @Override
    public int deleteByPrimaryKey(Integer id) {
        return dloadfileMapper.deleteByPrimaryKey(id);
    }

    @Override
    public int insert(Dloadfile user) {
        return dloadfileMapper.insert(user);
    }

    @Override
    public Dloadfile selectByPrimaryKey(Integer id) {
        return dloadfileMapper.selectByPrimaryKey(id);
    }

    @Override
    public int update(Dloadfile user) {
        return dloadfileMapper.update(user);
    }
}
