package com.panle.controller;

import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.UUID;


@RestController
@RequestMapping("/fileuntil")
public class FileUntilController {
    /**
     * 作者:Liu
     * file表里面的name是上传文件的名字，但是储存的名字(path,例如d98se0r.txt)是通过uuid生成
     *
     * */
    public UUID uuid = UUID.randomUUID();//不重复的id
    /**
     * 将上传的文件保存到不同的路径下
     * */
    @Value("${prop.upload-folderDOC}")
    private String UPLOAD_FOLDERDOC;
    @Value("${prop.upload-folderTEXT}")
    private String UPLOAD_FOLDERTEXT;
    @Value("${prop.upload-folderHTML}")
    private String UPLOAD_FOLDERHTML;
    @Value("${prop.upload-folderPDF}")
    private String UPLOAD_FOLDERPDF;
    @Value("${prop.upload-folderPPT}")
    private String UPLOAD_FOLDERPPT;
    @Value("${prop.upload-folderZIP}")
    private String UPLOAD_FOLDERZIP;
    @Value("${prop.upload-folderJPG}")
    private String UPLOAD_FOLDERJPG;
    @Value("${prop.upload-folderOTHERS}")
    private String UPLOAD_FOLDEROTHERS;
    private String filename;
    private static final Logger logger = LoggerFactory.getLogger(FileController.class);


    public boolean SaveFile(String savePath,String suffix,MultipartFile file){
        File savePathFile = new File(savePath);
        if (!savePathFile.exists()) {
            //若不存在该目录，则创建目录
            savePathFile.mkdirs();
        }
        //通过UUID生成唯一文件名
        filename = UUID.randomUUID().toString().replaceAll("-","") + "." + suffix;
        try {
            //将文件保存指定目录
            file.transferTo(new File(savePath + filename));
        } catch (Exception e) {
            e.printStackTrace();
            //return  ""+savePath+filename;
            return  false;
        }
        return true;
    }
    @PostMapping("/uploadFile")
    public String uploadFile(@RequestParam(name = "file", required = false) MultipartFile file,
                             HttpServletRequest request) {
        boolean IsSaveFileOk=false;
        if (file == null) {
            return "请选择要上传的文件";
        }
        if (file.getSize() > 1024 * 1024 * 30) {
            return "文件大小不能大于30M";
        }
        //获取文件后缀
        String suffix = file.getOriginalFilename().substring(file.getOriginalFilename().lastIndexOf(".") + 1, file.getOriginalFilename().length());
        /**
         * 根据不同后缀的文件保存到不同路径下
         * */
        switch(suffix.toUpperCase()) {
            case"JPG":IsSaveFileOk=SaveFile(UPLOAD_FOLDERJPG,suffix,file);break;
            case"DOC":IsSaveFileOk=SaveFile(UPLOAD_FOLDERDOC,suffix,file);break;
            case"HTML":IsSaveFileOk=SaveFile(UPLOAD_FOLDERHTML,suffix,file);break;
            case"PDF":IsSaveFileOk=SaveFile(UPLOAD_FOLDERPDF,suffix,file);break;
            case"PPT":IsSaveFileOk=SaveFile(UPLOAD_FOLDERPPT,suffix,file);break;
            case"TXT":IsSaveFileOk=SaveFile(UPLOAD_FOLDERTEXT,suffix,file);break;
            case"ZIP":IsSaveFileOk=SaveFile(UPLOAD_FOLDERZIP,suffix,file);break;
            default:IsSaveFileOk=SaveFile(UPLOAD_FOLDEROTHERS,suffix,file);break;
        }
        System.out.println(IsSaveFileOk?"文件保存正常，文件名字 : "+filename:"文件保存异常!!!");
        return IsSaveFileOk?"文件保存正常，文件名字 :"+filename:"文件保存异常!!!";
    }
    @RequestMapping("/download")
    public Object downloadFile(@RequestParam String fileName,@RequestParam String suffix, final HttpServletResponse response, final HttpServletRequest request){
        System.out.println(fileName+"\n"+suffix);
        OutputStream os = null;
        InputStream is= null;
        try {
            // 取得输出流
            os = response.getOutputStream();
            // 清空输出流
            response.reset();
            /**
             * 先获取下载文件的后缀，
             * 然后设置下载文件的格式
             * 以及获取其路径
             * */
            File f=null;

            switch(suffix){
                case"txt":response.setContentType("text/plain;charset=GBK");//application/x-download为txt格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                     f= new File(UPLOAD_FOLDERTEXT+fileName);break;
                case"doc":response.setContentType("application/msword;charset=GBK");//application/x-download为doc格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                    f= new File(UPLOAD_FOLDERDOC+fileName);break;
                case"html":response.setContentType("text/html;charset=GBK");//application/x-download为doc格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                    f= new File(UPLOAD_FOLDERHTML+fileName);break;
                case"jpg":response.setContentType("application/x-jpg;charset=GBK");//application/x-download为doc格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                    f= new File(UPLOAD_FOLDERJPG+fileName);break;
                case"pdf":response.setContentType("application/pdf;charset=GBK");//application/x-download为doc格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                    f= new File(UPLOAD_FOLDERPDF+fileName);break;
                case"ppt":response.setContentType("application/x-ppt;charset=GBK");//application/x-download为doc格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                    f= new File(UPLOAD_FOLDERPPT+fileName);break;
                case"zip":response.setContentType("application/zip;charset=GBK");//application/x-download为doc格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                    f= new File(UPLOAD_FOLDERZIP+fileName);break;
                default:response.setContentType("application/octet-stream;charset=GBK");//application/x-download为doc格式
                    response.setHeader("Content-Disposition", "attachment;filename="+ new String(fileName.getBytes("utf-8"), "iso-8859-1"));
                    //读取流
                    f= new File(UPLOAD_FOLDEROTHERS+fileName);break;



            }
            is = new FileInputStream(f);
            if (is == null) {
                logger.error("下载附件失败，请检查文件“" + fileName + "”是否存在");
                System.out.println("下载附件失败，请检查文件“" + fileName + "”是否存在");
                return "下载附件失败，请检查文件“" + fileName + "”是否存在";
            }
            //复制
            IOUtils.copy(is, response.getOutputStream());
            response.getOutputStream().flush();
        } catch (IOException e) {
            System.out.println("下载附件失败,error:"+e.getMessage());
            return "下载附件失败,error:"+e.getMessage();
        }
        //文件的关闭放在finally中
        finally
        {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                logger.error(String.valueOf(e));
            }
            try {
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
                logger.error(String.valueOf(e));
            }
        }
        System.out.println("下载成功" + fileName  );
        return "下载成功";
    }
    /**
     * path的名字是uuid生成的，前端删除时应该先按name找到，在给后端接口返回path以及type为suffix
     * 注意DeleteMapping
     * */
    @DeleteMapping("/deleteFile")
    public String deleteFile(@RequestParam("path")String path,@RequestParam("suffix")String suffix){
        File file = null;
        switch(suffix){
            case"jpg":file=new File(UPLOAD_FOLDERJPG+path);break;
            case"doc":file=new File(UPLOAD_FOLDERDOC+path);break;
            case"html":file=new File(UPLOAD_FOLDERHTML+path);break;
            case"pdf":file=new File(UPLOAD_FOLDERPDF+path);break;
            case"ppt":file=new File(UPLOAD_FOLDERPPT+path);break;
            case"txt":file=new File(UPLOAD_FOLDERTEXT+path);break;
            case"zip":file=new File(UPLOAD_FOLDERZIP+path);break;
            default:file=new File(UPLOAD_FOLDEROTHERS+path);break;
        }
        if (file.exists()){//文件是否存在
            file.delete();//删除文件
            return "删除"+path+"成功";
        }
        return "删除"+path+"失败";
    }
}
