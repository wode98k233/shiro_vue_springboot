package com.panle.controller;

import com.panle.pojo.File;
import com.panle.pojo.User;
import com.panle.service.FileServiceImpl;
import com.panle.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/file")
public class FileController {
    @Autowired
    FileServiceImpl fileService;
    @RequestMapping("/findAll")
    public List<File> findAll() {
        return fileService.findAll();
    }
    @GetMapping("/selectById")
    public File findById(@RequestParam("id")Integer id) {
        return fileService.selectByPrimaryKey(id);
    }
    @GetMapping("/selectByName")
    public File findByName(@RequestParam("name")String name) {
        return fileService.queryFileByName(name);
    }
    @PostMapping("/insert")
    public int addFile(@RequestBody File file) {
        Integer orderId= UUID.randomUUID().toString().replace("-","").hashCode();
        orderId = orderId < 0 ? -orderId : orderId;
        file.setId(Integer.valueOf(orderId));
        Timestamp d = new Timestamp(System.currentTimeMillis());
        file.setTime(d);
        System.out.println(d);
        System.out.println(file);
        return fileService.insert(file);
    }
    @DeleteMapping("/delete")
    public int deleteFile(@RequestParam("id")Integer id){
        return fileService.deleteByPrimaryKey(id);
    }
    @PutMapping("/update")
    public int updateFile(@RequestBody File file){
        return fileService.update(file);
    }
}
