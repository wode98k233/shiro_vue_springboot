package com.panle.controller;

import com.panle.pojo.User;
import com.panle.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    UserServiceImpl userService;
    @RequestMapping("/findAll")
    public List<User> findAll() {
        return userService.findAll();
    }
    @GetMapping("/selectById")
    public User findById(@RequestParam("id")Integer id) {
        return userService.selectByPrimaryKey(id);
    }
    @GetMapping("/selectByName")
    public User findByName(@RequestParam("name")String name) {
        return userService.queryUserByName(name);
    }
    @PostMapping("/insert")
    public int addUser(@RequestBody User user) {
        //通过uuid生成唯一id
        Integer orderId=UUID.randomUUID().toString().replace("-","").hashCode();
        orderId = orderId < 0 ? -orderId : orderId;
        user.setId(Integer.valueOf(orderId));
        Timestamp d = new Timestamp(System.currentTimeMillis());
        user.setBtime(d);
        System.out.println(user);
        return userService.insert(user);
    }
    @DeleteMapping("/delete")
    public int deleteUser(@RequestParam("id")Integer id){
        return userService.deleteByPrimaryKey(id);
    }
    @PutMapping("/update")
    public int updateUser(@RequestBody User user){
        return userService.update(user);
    }
}
