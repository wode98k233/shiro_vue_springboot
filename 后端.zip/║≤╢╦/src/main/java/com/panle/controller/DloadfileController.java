package com.panle.controller;

import com.panle.pojo.Dloadfile;
import com.panle.pojo.File;
import com.panle.service.DloadfileServiceImpl;
import com.panle.service.FileServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/dloadfile")
public class DloadfileController {
    @Autowired
    DloadfileServiceImpl dloadfile;
    @RequestMapping("/findAll")
    public List<Dloadfile> findAll() {
        return dloadfile.findAll();
    }
    @GetMapping("/selectById")
    public Dloadfile findById(@RequestParam("id")Integer id) {
        return dloadfile.selectByPrimaryKey(id);
    }
    @GetMapping("/selectByFName")
    public Dloadfile findByFName(@RequestParam("name")String name) {
        return dloadfile.queryDloadfileByFName(name);
    }
    @PostMapping("/insert")
    public int addDloadfile(@RequestBody Dloadfile dt) {
        Integer orderId= UUID.randomUUID().toString().replace("-","").hashCode();
        orderId = orderId < 0 ? -orderId : orderId;
        dt.setHid(Integer.valueOf(orderId));
        Timestamp d = new Timestamp(System.currentTimeMillis());
        dt.setTime(d);
        return dloadfile.insert(dt);
    }
    @DeleteMapping("/delete")
    public int deleteDloadfile(@RequestParam("id")Integer id){
        return dloadfile.deleteByPrimaryKey(id);
    }
    @PutMapping("/update")
    public int updateDloadfile(@RequestBody Dloadfile dt){
        return dloadfile.update(dt);
    }
}
