package com.panle;

import com.panle.pojo.User;
import com.panle.service.UserServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

@SpringBootTest
class PanleApplicationTests {
    @Autowired
    UserServiceImpl userService;
    @Test
    void contextLoads() {
        Timestamp d = new Timestamp(System.currentTimeMillis());
        /*User user=new User(3,"newP","985214",d
                ,"男","741258963@wy.com","2342342355");
        user.setId(88);*/
        System.out.println(d);

    }

}
